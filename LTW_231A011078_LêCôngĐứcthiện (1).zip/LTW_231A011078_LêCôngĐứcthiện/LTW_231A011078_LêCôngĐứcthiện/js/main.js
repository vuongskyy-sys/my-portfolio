/* =======================
   KIỂM TRA ĐƯỜNG DẪN
======================= */

const isInHtmlFolder = window.location.pathname.includes("/html/");
const pathPrefix = isInHtmlFolder ? "../" : "";


/* =======================
   DANH SÁCH SẢN PHẨM
======================= */

const products = [
{ id:1, name:"Bút bi Thiên Long", price:5000, image:"images/but.jpg", description:"Bút bi viết êm, mực ra đều.", rating:4.5 },
{ id:2, name:"Tập vở học sinh", price:12000, image:"images/tapvo.jpg", description:"Tập 200 trang.", rating:4.2 },
{ id:3, name:"Bìa hồ sơ", price:8000, image:"images/biahoso.jpg", description:"Bìa đựng tài liệu.", rating:4.0 },
{ id:4, name:"Máy tính Casio FX-570VN", price:550000, image:"images/maytinhcasio.jpg", description:"Máy tính chính hãng.", rating:4.8 },
{ id:5, name:"Thước kẻ 30cm", price:7000, image:"images/thuocke.jpg", description:"Thước nhựa dẻo.", rating:4.1 },
{ id:6, name:"Balo học sinh", price:250000, image:"images/balo.jpg", description:"Balo chống nước.", rating:4.6 },
{ id:7, name:"Sách giáo khoa", price:15000, image:"images/sachgiaokhoa.jpg", description:"Sách chương trình mới.", rating:4.3 },
{ id:8, name:"Truyện tranh thiếu nhi", price:30000, image:"images/truyen.jpg", description:"Truyện tranh giải trí.", rating:4.4 },
{ id:9, name:"Sổ tay cao cấp", price:45000, image:"images/sotay.jpg", description:"Sổ tay bìa da.", rating:4.7 }
];


/* =======================
   HIỂN THỊ SẢN PHẨM
======================= */

const productList = document.getElementById("productList");

if(productList){
    displayProducts(products);
/* =======================
   TÌM KIẾM SẢN PHẨM
======================= */

function searchProduct(){

    const input = document.getElementById("searchInput");

    if(!input) return;

    const keyword = input.value.toLowerCase().trim();

    const result = products.filter(product =>
        product.name.toLowerCase().includes(keyword)
    );

    displayProducts(result);
}

const searchInput = document.getElementById("searchInput");

if(searchInput){
    searchInput.addEventListener("keyup", searchProduct);
}
}

function displayProducts(data){
    productList.innerHTML = "";

    data.forEach(p=>{
        productList.innerHTML += `
        <div class="product-card">
            <img src="${pathPrefix + p.image}" alt="${p.name}">
            <h3>${p.name}</h3>
            <p>${p.description}</p>
            <p>⭐ ${p.rating}</p>
            <p><strong>${p.price.toLocaleString()}đ</strong></p>
            <button onclick="addToCart(${p.id})">Thêm vào giỏ</button>
            <button onclick="buyNow(${p.id})">Mua ngay</button>
            <button onclick="viewDetail(${p.id})">Xem chi tiết</button>
        </div>
        `;
    });
}


/* =======================
   MUA NGAY
======================= */

function buyNow(id){
    addToCart(id);
    window.location = isInHtmlFolder ? "cart.html" : "html/cart.html";
}


/* =======================
   CHI TIẾT SẢN PHẨM
======================= */

function viewDetail(id){
    localStorage.setItem("detailId", id);
    window.location = isInHtmlFolder ? "product.html" : "html/product.html";
}

const detailContainer = document.getElementById("productDetail");

if(detailContainer){
    const id = parseInt(localStorage.getItem("detailId"));
    const product = products.find(p=>p.id === id);

    if(product){
        detailContainer.innerHTML = `
            <h2>${product.name}</h2>
            <img src="${pathPrefix + product.image}" width="250">
            <p>${product.description}</p>
            <p>⭐ ${product.rating}</p>
            <p><strong>${product.price.toLocaleString()}đ</strong></p>
            <button onclick="addToCart(${product.id})">Thêm vào giỏ</button>
            <hr>
            <h3>Bình luận</h3>
            <div id="commentList"></div>
            <textarea id="commentText" placeholder="Nhập bình luận"></textarea>
            <button onclick="addComment(${product.id})">Gửi</button>
        `;

        displayComments(id);
    }
}


/* =======================
   BÌNH LUẬN
======================= */

function addComment(id){
    const text = document.getElementById("commentText").value;
    if(text==="") return;

    let comments = JSON.parse(localStorage.getItem("comments_"+id)) || [];
    comments.push(text);

    localStorage.setItem("comments_"+id, JSON.stringify(comments));
    document.getElementById("commentText").value="";
    displayComments(id);
}

function displayComments(id){
    const list=document.getElementById("commentList");
    if(!list) return;

    let comments=JSON.parse(localStorage.getItem("comments_"+id))||[];
    list.innerHTML=comments.map(c=>`<p>• ${c}</p>`).join("");
}


/* =======================
   GIỎ HÀNG (FULL FIX)
======================= */

function getCart(){
    return JSON.parse(localStorage.getItem("cart")) || [];
}

function saveCart(cart){
    localStorage.setItem("cart", JSON.stringify(cart));
}

function addToCart(id){
    let cart = getCart();
    const product = products.find(p=>p.id===id);
    const existing = cart.find(item=>item.id===id);

    if(existing){
        existing.quantity++;
    }else{
        cart.push({...product, quantity:1});
    }

    saveCart(cart);
    alert("Đã thêm vào giỏ hàng!");
}


/* =======================
   HIỂN THỊ GIỎ HÀNG
======================= */

const cartItems = document.getElementById("cartItems");

if(cartItems){
    renderCart();
}

function renderCart(){
    let cart = getCart();
    let total = 0;
    let html = "";

    if(cart.length===0){
        html="<p>Giỏ hàng đang trống</p>";
    }else{
        cart.forEach((item,index)=>{
            total += item.price*item.quantity;

            html+=`
            <div>
                <strong>${item.name}</strong><br>
                ${item.quantity} x ${item.price.toLocaleString()}đ
                <button onclick="changeQty(${index},-1)">-</button>
                <button onclick="changeQty(${index},1)">+</button>
                <button onclick="removeItem(${index})">Xóa</button>
                <p>Thành tiền: ${(item.price*item.quantity).toLocaleString()}đ</p>
                <hr>
            </div>
            `;
        });
    }

    cartItems.innerHTML=html;

    const totalElement=document.getElementById("total");
    if(totalElement){
        totalElement.innerText="Tổng tiền: "+total.toLocaleString()+"đ";
    }
}

function changeQty(index,value){
    let cart = getCart();

    cart[index].quantity += value;

    if(cart[index].quantity <= 0){
        cart.splice(index,1);
    }

    saveCart(cart);
    renderCart();
}

function removeItem(index){
    let cart = getCart();
    cart.splice(index,1);
    saveCart(cart);
    renderCart();
}


/* =======================
   THANH TOÁN
======================= */

function goCheckout(){
    let cart = getCart();

    if(cart.length===0){
        alert("Giỏ hàng trống!");
        return;
    }

    window.location="checkout.html";
}

function checkout(){
    alert("Đặt hàng thành công!");
    localStorage.removeItem("cart");
    window.location="../index.html";
}


/* =======================
   QUẢN LÝ NGƯỜI DÙNG
======================= */

let users = JSON.parse(localStorage.getItem("users")) || [];

function register(){
    const username=document.getElementById("regUsername").value;
    const password=document.getElementById("regPassword").value;

    if(username===""||password===""){
        alert("Vui lòng nhập đầy đủ thông tin");
        return;
    }

    if(users.find(u=>u.username===username)){
        alert("Tài khoản đã tồn tại");
        return;
    }

    users.push({username,password});
    localStorage.setItem("users",JSON.stringify(users));

    alert("Đăng ký thành công!");
    window.location="login.html";
}

function login(){
    const username=document.getElementById("loginUsername").value;
    const password=document.getElementById("loginPassword").value;

    const user=users.find(u=>u.username===username&&u.password===password);

    if(user){
        localStorage.setItem("currentUser",username);
        alert("Đăng nhập thành công!");
        window.location="../index.html";
    }else{
        alert("Sai tài khoản hoặc mật khẩu");
    }
}